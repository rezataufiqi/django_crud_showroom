from django.db import models

class showroom(models.Model):
  judul = models.CharField(max_length=200)
  publish = models.DateTimeField("Tanggal Publikasi")

  def __str__(self):
    return self.judul