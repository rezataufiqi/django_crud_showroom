from django.urls import path
from . import views

urlpatterns = [
    # /showroom/
    path('', views.index, name='showroom.index'),
    # /showroom/add/
    path('add/', views.add, name='showroom.add'),
    # /showroom/save/
    path('save/', views.save, name='showroom.save'),
    # /showroom/edit/1
    path('edit/<int:showroom_id>/', views.edit, name='showroom.edit'),
    # /showroom/update/1
    path('update/<int:showroom_id>/', views.update, name='showroom.update'),
    # /showroom/delete/1
    path('delete/<int:showroom_id>/', views.delete, name='showroom.delete'),
]