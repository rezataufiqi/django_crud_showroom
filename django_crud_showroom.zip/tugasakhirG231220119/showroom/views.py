from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import showroom


def index(request):
    # Mengambil semua data dari model showroom
    context = {'showroom_list': showroom.objects.all()}
    return render(request, 'showroom/index.html', context)


def add(request):
    # Menampilkan halaman form untuk menambahkan showroom baru
    return render(request, 'showroom/form.html')


def save(request):
    # Menyimpan data showroom baru
    buku = showroom(
        judul=request.POST['judul'],
        publish=request.POST['publish']
    )
    buku.save()
    return HttpResponseRedirect(reverse('showroom.index'))


def delete(request, showroom_id):
    # Menghapus data showroom berdasarkan ID
    buku = get_object_or_404(showroom, pk=showroom_id)
    buku.delete()
    return HttpResponseRedirect(reverse('showroom.index'))


def edit(request, showroom_id):
    # Mengedit data showroom berdasarkan ID
    buku = get_object_or_404(showroom, pk=showroom_id)
    context = {
        'id': showroom_id,
        'judul': buku.judul,
        'publish': buku.publish.strftime("%Y-%m-%d")
    }
    return render(request, 'showroom/form_edit.html', context)


def update(request, showroom_id):
    # Memperbarui data showroom berdasarkan ID
    buku = get_object_or_404(showroom, pk=showroom_id)
    buku.judul = request.POST['judul']
    buku.publish = request.POST['publish']
    buku.save()
    return HttpResponseRedirect(reverse('showroom.index'))
